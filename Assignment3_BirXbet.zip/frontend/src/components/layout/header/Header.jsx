
function Header() {
    return (
        <header className="header">
            <h1 className="header-title">Bet Company</h1>
        </header>
    )
}

export default Header