import Header from '@/components/layout/Header/Header';

function HomePage() {
    return (
        <>
            <Header />
        </>
    )
}

export default HomePage