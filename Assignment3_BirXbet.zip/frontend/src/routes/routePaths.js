export const ROUTES = {
    HOME: "/"
};